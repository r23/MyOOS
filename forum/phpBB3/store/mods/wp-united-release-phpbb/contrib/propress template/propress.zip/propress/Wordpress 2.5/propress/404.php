<?php get_header(); ?>

<div id="contentwrap">
  <div class="clear"></div>
  <div id="content">
    <div class="contentbody bg2">
      <div class="inner"><span class="corners-top"><span></span></span>
        <h2 class="center">Error 404 - Not Found</h2>
        <span class="corners-bottom"><span></span></span> </div>
    </div>
  </div>
  <div id="sidebar">
    <?php get_sidebar(); ?>
  </div>
</div>
<?php get_footer(); ?>