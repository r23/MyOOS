<?php

// HAWHAW example for (quite a stupid) password authentication
// (adapted for nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

if (!isset($_REQUEST['submit']))
{
  // pass 1

  $AuthPage = new NIHAO_deck("Authenticate", HAW_ALIGN_CENTER);

  $myForm = new HAW_form($_SERVER['PHP_SELF']); 

  $text = new HAW_text("Please enter some digits:"); 
  $theID = new HAW_input("id", "", "Account",  "*N");
  $theID->set_size(4);
  $theID->set_maxlength(4);

  $thePW = new HAW_input("pw", "", "Password", "*N");
  $thePW->set_size(4);
  $thePW->set_maxlength(4);
  $thePW->set_type(HAW_INPUT_PASSWORD);

  $theSubmission = new HAW_submit("Submit", "submit");

  $myForm->add_text($text);
  $myForm->add_input($theID);
  $myForm->add_input($thePW);
  $myForm->add_submit($theSubmission);

  $AuthPage->add_form($myForm);

  $AuthPage->create_page();
}
else
{
  // form was filled and submitted - pass 2

  $WelcomePage = new NIHAO_deck("", HAW_ALIGN_CENTER);

  $text1 = new NIHAO_text("Hello " . $_REQUEST['id'], HAW_TEXTFORMAT_BIG); 
  $text2 = new NIHAO_text("Your password expires in 3 days!", HAW_TEXTFORMAT_SMALL); 

  $WelcomePage->add_text($text1);
  $WelcomePage->add_text($text2);

  $WelcomePage->create_page();
}

?>
