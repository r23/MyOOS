<?php

// HAWHAW example to show different text formats
// (adapted for nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

$myPage = new NIHAO_deck("Example 1");

$myText1 = new HAW_text("Some text formats", HAW_TEXTFORMAT_BOXED);
$myText1->set_color("yellow", "#889988"); // works with (X)HTML only 
$myText2 = new HAW_text("This is bold", HAW_TEXTFORMAT_BOLD);
$myText3 = new HAW_text("This is italic", HAW_TEXTFORMAT_ITALIC);
$myText4 = new HAW_text("Underlined", HAW_TEXTFORMAT_UNDERLINE); 
$myText5 = new HAW_text("BIG", HAW_TEXTFORMAT_BIG); 
$myText6 = new HAW_text("and very small", HAW_TEXTFORMAT_SMALL); 
$myText7 = new NIHAO_text("And this is NIHAO_text.");

$myRule = new HAW_rule();

$myPage->add_text($myText1);
$myPage->add_text($myText2);
$myPage->add_text($myText3);
$myPage->add_text($myText4);
$myPage->add_text($myText5);
$myPage->add_text($myText6);

$myPage->add_rule($myRule);

$myPage->add_text($myText7);

$myPage->create_page();

?>
