<?php

// HAWHAW example how to initiate phone calls
// (adapted for nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

$PhonePage = new NIHAO_deck("Example 9");

$text1 = new NIHAO_text("If you browse this deck on a WAP or i-Mode phone, establishing a call is easy as following a link.");
$text1->set_br(2);
$PhonePage->add_text($text1);

$phone = new NIHAO_phone("+1 407 386 3678", "CALL");
$PhonePage->add_phone($phone);

$PhonePage->create_page();

?>
