<?php

// HAWHAW example for usage of radio buttons
// (adapted nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

if (!isset($_REQUEST['submit']))
{
  // pass 1

  $SelPage = new NIHAO_deck("Booking");

  $myForm = new HAW_form($_SERVER['PHP_SELF']); 

  $text = new HAW_text("Please select your flight destination:"); 
  $rb = new HAW_radio("dest"); 
  $rb->add_button("Helsinki", "Helsinki");
  $rb->add_button("Munich", "Munich", HAW_CHECKED);
  $rb->add_button("Paris", "Paris");
  $rb->add_button("Stockholm", "Stockholm");
  $sbt = new HAW_submit("Submit", "submit");

  $myForm->add_text($text);
  $myForm->add_radio($rb);
  $myForm->add_submit($sbt);

  $SelPage->add_form($myForm);

  $SelPage->create_page();
}
else
{
  // form has been submitted - pass 2

  $ExcusePage = new NIHAO_deck("Confirmation", HAW_ALIGN_CENTER);

  $text1 = new NIHAO_text("Sorry,", HAW_TEXTFORMAT_BIG | HAW_TEXTFORMAT_BOLD | HAW_TEXTFORMAT_ITALIC); 
  $text2 = new NIHAO_text("All flights to " . $_REQUEST['dest'] . " are totally booked out!", HAW_TEXTFORMAT_ITALIC); 

  $ExcusePage->add_text($text1);
  $ExcusePage->add_text($text2);

  $backlink = new NIHAO_backButton("Booking", $_SERVER['PHP_SELF']);
  $ExcusePage->add_link($backlink);
  
  $ExcusePage->create_page();
}

?>
