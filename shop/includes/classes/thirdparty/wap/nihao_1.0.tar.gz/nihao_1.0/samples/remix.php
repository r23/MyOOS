<?php

// HAWHAW iPhone web application demo
// Norbert Huffschmid
// http://www.hawhaw.de/
// $Date: 2008/08/15 19:50:09 $
//
// This script is a HAWHAW-based re-implementation of the iUI music demo:
// http://iui.googlecode.com/svn/tags/REL-current/samples/music.html


require("../hawhaw.inc"); // HAWHAW PHP library
require("../nihao.php");  // Nihao wrapper for HAWHAW

// our artist/album database ...
$songs = array(
  0 => array ("Herbert Grönemeyer", "4630 Bochum", "Mensch", "12"),
  1 => array ("Joe Cocker", "Unchain My Heart", "Joe Cocker Live", "Have a Little Faith", "Respect Yourself"),
  2 => array ("Scorpions", "In Trance", "Lovedrive", "Rhythm Of Love", "Fly To The Rainbow"),
  3 => array ("Shakira", "Laundry Service"),
  4 => array ("Shania Twain", "Up!"),
  5 => array ("Tokio Hotel", "Scream/Room 483")
);

// this file handles all HTTP requests
// depending on the "page" parameter different output is created ...

if (!isset($_REQUEST['page']) ||
    ($_REQUEST['page'] == "home"))
{
  // this is the main page
  
  // All NIHAO_xxx classes are Nihao-specific subclasses of HAWHAW base classes
  $deck = new NIHAO_deck("Music");
  $deck->set_panel(false); // don't use pinstripes background here ...
  
  $linkset = new HAW_linkset();
  $artists_link  = new HAW_link("Artists", $_SERVER['PHP_SELF'] . "?page=artists");
  $settings_link = new HAW_link("Settings", $_SERVER['PHP_SELF'] . "?page=settings");
  $stats_link = new HAW_link("Stats", $_SERVER['PHP_SELF'] . "?page=stats");
  $about_link = new HAW_link("About", "http://www.hawhaw.de/faq.htm#Nihao0");
  $linkset->add_link($artists_link);
  $linkset->add_link($settings_link);
  $linkset->add_link($stats_link);
  $linkset->add_link($about_link);
  $deck->add_linkset($linkset);
}
else if ($_REQUEST['page'] == "artists")
{
  // this is the Artist's page ...
  
  $deck = new NIHAO_deck("Artists");
  $deck->set_panel(false);
  
  $group_H = new NIHAO_listGroup("H");
  $deck->add_text($group_H);

  $herbertgroenemeyer = new NIHAO_link("Herbert Grönemeyer", $_SERVER['PHP_SELF'] . "?page=albums&id=0");
  $deck->add_link($herbertgroenemeyer);
  
  $group_J = new NIHAO_listGroup("J");
  $deck->add_text($group_J);

  $joecocker = new NIHAO_link("Joe Cocker", $_SERVER['PHP_SELF'] . "?page=albums&id=1");
  $deck->add_link($joecocker);
  
  $group_S = new NIHAO_listGroup("S");
  $deck->add_text($group_S);

  $scorpions = new NIHAO_link("Scorpions", $_SERVER['PHP_SELF'] . "?page=albums&id=2");
  $deck->add_link($scorpions);

  $shakira = new NIHAO_link("Shakira", $_SERVER['PHP_SELF'] . "?page=albums&id=3");
  $deck->add_link($shakira);
  
  $shaniatwain = new NIHAO_link("Shania Twain", $_SERVER['PHP_SELF'] . "?page=albums&id=4");
  $deck->add_link($shaniatwain);
    
  $group_T = new NIHAO_listGroup("T");
  $deck->add_text($group_T);

  $tokiohotel = new NIHAO_link("Tokio Hotel", $_SERVER['PHP_SELF'] . "?page=albums&id=5");
  $deck->add_link($tokiohotel);
  
  set_back_button($deck, "Music", "home");
}
else if ($_REQUEST['page'] == "albums")
{
  $deck = new NIHAO_deck($songs[$_REQUEST['id']][0]);
  $deck->set_panel(false);
  
  foreach ($songs[$_REQUEST['id']] as $key => $song) {
    if ($key > 0) { // first key is the artist!
      $songlink = new NIHAO_link($song, $_SERVER['PHP_SELF'] . "?page=songs");
      $deck->add_link($songlink);
    }
  }
  
  set_back_button($deck, "Artists", "artists");
}
else if ($_REQUEST['page'] == "songs")
{
  $deck = new NIHAO_deck("Songs");
  $deck->set_panel(false);
  
  for ($i=1; $i<=11; $i++) {
      $songlink = new NIHAO_link("Song " . $i, $_SERVER['PHP_SELF'] . "?page=player");
      $deck->add_link($songlink);
  }
  
  set_back_button($deck, "Artists", "artists");
}
else if ($_REQUEST['page'] == "player")
{
  $deck = new NIHAO_deck("Now Playing", HAW_ALIGN_CENTER);
  
  $text = new NIHAO_text("If this weren't just a demo, you might be hearing a song...");
  $deck->add_text($text);

  // let's offer a phone call to the HAWHAW voice demo instead ...
  $phone = new NIHAO_phone("+1 407 386 3678", "Listen to the HAWHAW voice demo: +1 407 386 3678");
  $deck->add_phone($phone);

  set_back_button($deck, "Songs", "songs");
}
else if ($_REQUEST['page'] == "searchdialog")
{
  $deck = new NIHAO_deck("Music Search");
  
  $form = new HAW_form($_SERVER['PHP_SELF']);
  
  $artist = new HAW_input("artist", "", "Artist");
  $song   = new HAW_input("song", "", "Song");
  $page   = new HAW_hidden("page", "songs");
  $searchButton = new HAW_submit("Search");
  $form->add_input($artist);
  $form->add_input($song);
  $form->add_hidden($page);
  $form->add_submit($searchButton);
  
  $deck->add_form($form);

  $cancelButton = new NIHAO_leftbutton("Cancel", $_SERVER['PHP_SELF']);
  $deck->add_link($cancelButton);
}
else if ($_REQUEST['page'] == "settings")
{
  $deck = new NIHAO_deck("Settings");

  $form = new HAW_form($_SERVER['PHP_SELF']);

  $section1 = new NIHAO_listGroup("Playback");
  $form->add_text($section1);
  
  $repeat  = new HAW_checkbox("repeat", "c", "Repeat");
  $shuffle = new HAW_checkbox("shuffle", "c", "Shuffle");
  $form->add_input($repeat);
  $form->add_input($shuffle);

  $section2 = new NIHAO_listGroup("User");
  $form->add_text($section2);
  
  $username = new HAW_input("username", "johnappleseed", "Name");
  $password = new HAW_input("pw", "delicious", "Password");
  $password->set_type(HAW_INPUT_PASSWORD);
  $confirm = new HAW_input("confirm", "delicious", "Confirm");
  $confirm->set_type(HAW_INPUT_PASSWORD);
  $form->add_input($username);
  $form->add_input($password);
  $form->add_input($confirm);
  
  $saveButton = new HAW_submit("Save");
  $form->add_submit($saveButton);
  
  $deck->add_form($form);
  
  $cancelButton = new NIHAO_leftbutton("Cancel", $_SERVER['PHP_SELF']);
  $deck->add_link($cancelButton);
}
else if ($_REQUEST['page'] == "stats")
{
  $deck = new NIHAO_deck("Stats");
  $deck->set_panel(false);
  
  $linkset = new HAW_linkset();
  $usage_link  = new HAW_link("Usage", $_SERVER['PHP_SELF'] . "?page=usage");
  $battery_link = new HAW_link("Battery", $_SERVER['PHP_SELF'] . "?page=battery");
  $linkset->add_link($usage_link);
  $linkset->add_link($battery_link);
  $deck->add_linkset($linkset);

  set_back_button($deck, "Music", "home");
}
else if ($_REQUEST['page'] == "usage")
{
  $deck = new NIHAO_deck("Usage");
  
  $title = new NIHAO_text("Play Time");
  $deck->add_text($title);
  
  // iUI music.html uses editable input fields here, which makes not so much sense
  // let's play with HAWHAW tables ...

  $years  = new HAW_text("Years", HAW_TEXTFORMAT_BOLD);
  $months = new HAW_text("Months", HAW_TEXTFORMAT_BOLD);
  $days   = new HAW_text("Days", HAW_TEXTFORMAT_BOLD);
  $value1 = new HAW_text("6");
  $value2 = new HAW_text("8");
  $value3 = new HAW_text("27");
  
  $statsTable = new HAW_table();
  $row1 = new HAW_row();
  $row1->add_column($years);  
  $row1->add_column($value1);
  $statsTable->add_row($row1);
  $row2 = new HAW_row();
  $row2->add_column($months);  
  $row2->add_column($value2);
  $statsTable->add_row($row2);
  $row3 = new HAW_row();
  $row3->add_column($days);  
  $row3->add_column($value3);
  $statsTable->add_row($row3);
  $deck->add_table($statsTable);
  
  set_back_button($deck, "Stats", "stats");
}
else if ($_REQUEST['page'] == "battery")
{
  $deck = new NIHAO_deck("Battery");
  
  $status = new NIHAO_text("Better recharge soon!");
  $deck->add_text($status);
  
  set_back_button($deck, "Stats", "stats");
}

if (!isset($_REQUEST['page']) ||
    ($_REQUEST['page'] != "player") &&
    ($_REQUEST['page'] != "searchdialog") &&
    ($_REQUEST['page'] != "settings"))
{
  // most pages have to provide a Search-Button at the upper right corner
  $searchButton = new NIHAO_toolButton("Search", $_SERVER['PHP_SELF'] . "?page=searchdialog");
  $deck->add_link($searchButton);
}

$deck->create_page(); // this throws out HAWHAW's output

// --- end of script ---



// some useful functions ...

function set_back_button(&$deck, $title, $page)
{
  $backButton = new NIHAO_backButton($title, $_SERVER['PHP_SELF'] . "?page=" . $page);
  $deck->add_link($backButton);
}

?>
