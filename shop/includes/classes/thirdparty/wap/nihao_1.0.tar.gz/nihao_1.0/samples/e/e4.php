<?php

// HAWHAW example for usage of checkboxes
// (adapted for nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

if (!isset($_REQUEST['solution']))
{
  // pass 1

  $CalcPage = new NIHAO_deck("Calculus");

  $myForm = new HAW_form($_SERVER['PHP_SELF']);
  // tell voice users what this here is all about 
  $myForm->set_voice_text("Say yes or no to the following statements"); 

  $cb1 = new HAW_checkbox("c1", "c", "2+3=6");
  // speech synthesizers (like many people) have some problems with math terms
  $cb1->set_voice_text("2 plus 3 is equal 6");
  $cb2 = new HAW_checkbox("c2", "c", "SIN(PI)=0"); 
  $cb2->set_voice_text("sinus of pee is equal 0");
  $cb3 = new HAW_checkbox("c3", "c", "SQRT(16)=4");
  $cb3->set_voice_text("squareroot of 16 is equal 4"); 
  $sbt = new HAW_submit("Solution", "solution");

  $myForm->add_checkbox($cb1);
  $myForm->add_checkbox($cb2);
  $myForm->add_checkbox($cb3);
  $myForm->add_submit($sbt);

  $CalcPage->add_form($myForm);

  $CalcPage->create_page();
}
else
{
  // form has been submitted - pass 2

  $ResultPage = new NIHAO_deck("Result");

  $points = 0;

  if (!isset($_REQUEST['c1']) || (strcmp($_REQUEST['c1'], 'c') != 0))
    $points += 1;
  else
    $comment1 = "You don't go to school yet, do you?";

  if (isset($_REQUEST['c2']) && (strcmp($_REQUEST['c2'], 'c') == 0))
    $points += 2;
  else
    $comment2 = "Do you know what a circle is?";

  if (isset($_REQUEST['c3']) && (strcmp($_REQUEST['c3'], 'c') == 0))
    $points += 3;
  else
    $comment3 = "Have you heard about squares and roots?";

  if ($points > 0)
    $text1 = new HAW_text("Congratulations!", HAW_TEXTFORMAT_UNDERLINE);
  else
    $text1 = new HAW_text("Hmmmh,...");

  $ResultPage->add_text($text1);

  $text2 = new HAW_text("You reached $points from 6 points.");
  $ResultPage->add_text($text2);

  if ($points == 6)
  {
    $text3 = new HAW_text("You seem to be a genius!");
    $ResultPage->add_text($text3);
  }
  else
  {
    if (isset($comment3))
    { 
      $tc3 = new HAW_text($comment3);
      $ResultPage->add_text($tc3);
    }

    if (isset($comment2))
    { 
      $tc2 = new HAW_text($comment2);
      $ResultPage->add_text($tc2);
    }

    if (isset($comment1))
    { 
      $tc1 = new HAW_text($comment1);
      $ResultPage->add_text($tc1);
    }
  }

  $backlink = new NIHAO_backButton("Calculus", $_SERVER['PHP_SELF']);
  $ResultPage->add_link($backlink);
  
  $ResultPage->create_page();
}

?>
