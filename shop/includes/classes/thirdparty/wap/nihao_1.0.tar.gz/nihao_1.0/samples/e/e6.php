<?php

// HAWHAW example how to include images
// (adapted for nihao.php)
// Norbert Huffschmid
// $Date: 2008/08/15 19:50:09 $

require("../../hawhaw.inc");
require("../../nihao.php");

$ImagePage = new NIHAO_deck("Example 6");
$ImagePage->set_panel(false); // turn off pinstripes background

$title = new HAW_text("Images", HAW_TEXTFORMAT_BOLD | HAW_TEXTFORMAT_UNDERLINE);
$ImagePage->add_text($title);

$main_image = new HAW_image("http://www.hawhaw.de/e/hawhaw.wbmp",
                            "http://www.hawhaw.de/e/hawhaw.gif",
                            "HAWHAW",
                            "http://www.hawhaw.de/e/hawhaw.bmp");
$main_image->set_br(1); // create 1 line break
$ImagePage->add_image($main_image);

$header1  = new HAW_text("These are images combined with pure text:");
$ImagePage->add_text($header1);

$image1 = new HAW_image("http://www.hawhaw.de/e/o_smiley.wbmp",
                        "http://www.hawhaw.de/e/o_smiley.gif",
                        ":-)",
                        "http://www.hawhaw.de/e/o_smiley.bmp");
$ImagePage->add_image($image1);
$text1  = new HAW_text("Saturday");
$ImagePage->add_text($text1);

$image2 = new HAW_image("http://www.hawhaw.de/e/o_hmm.wbmp",
                        "http://www.hawhaw.de/e/o_hmm.gif",
                        ":-|",
                        "http://www.hawhaw.de/e/o_hmm.bmp");
$ImagePage->add_image($image2);
$text2  = new HAW_text("Sunday");
$ImagePage->add_text($text2);

$image3 = new HAW_image("http://www.hawhaw.de/e/o_angry.wbmp",
                        "http://www.hawhaw.de/e/o_angry.gif",
                        ":-(",
                        "http://www.hawhaw.de/e/o_angry.bmp");
$ImagePage->add_image($image3);
$text3  = new HAW_text("Monday");
$text3->set_br(2); // create 2 line breaks
$ImagePage->add_text($text3);

$header2  = new HAW_text("But they work with links too:");
$ImagePage->add_text($header2);

$link1 = new NIHAO_link("Example 1","e1.php");
$link1->add_image($image1);
$ImagePage->add_link($link1);

$ImagePage->set_voice_jingle("jingle.wav"); // link indication for voice users

$ImagePage->create_page();

?>
