<?php
require_once('../tera_wurfl_config.php');
require_once(WURFL_PARSER_FILE);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Tera-WURFL Installation</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
<table width="800">
	<tr><td>
<div align="center" class="titlediv">
	<p>		Tera-WURFL Installation <br />
		<span class="version">Version <?php echo "$branch $version"; ?></span></p>
</div>
</td></tr><tr><td>
	<p>&nbsp;</p>
	<table width="800" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<th colspan="2" scope="col">Checking Installation </th>
		</tr>
		<tr>
			<td width="16" height="32" class="lightrow">&nbsp;</td>
			<td width="744" valign="bottom" class="lightrow"><p><strong>File Permissions</strong>:
<br />
</p>			</td>
</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="darkrow">WURFL File: <?php echo WURFL_FILE?>...
				<?php
if(is_file(WURFL_FILE) && is_readable(WURFL_FILE))
echo "OK";
else
echo "<span class=\"error\">WARNING:</span> File doesn't exist or isn't readable.  You can continue like this, you just can't update the database from your local wurfl.xml.";
?></td>
		</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="lightrow">PATCH File: <?php echo WURFL_PATCH_FILE?>...
				<?php
if(is_file(WURFL_PATCH_FILE) && is_readable(WURFL_PATCH_FILE))
echo "OK";
else
echo "<span class=\"error\">WARNING:</span> File doesn't exist or isn't readable.  You may ignore this error if patching is disabled.";
?></td>
		</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="darkrow">DATA Directory: <?php echo DATADIR?>...
				<?php
if(is_dir(DATADIR) && is_readable(DATADIR) && is_writable(DATADIR))
echo "OK";
else
echo "<span class=\"error\">ERROR:</span> Directory doesn't exist or isn't writeable.  This directory should be owned by the webserver user or chmoded to 777 for the log file and the online updates to work.";
?></td>
		</tr>
		<tr>
<td height="31" class="darkrow">&nbsp;</td>
<td valign="bottom" class="lightrow"><p><strong>Database</strong>:</p></td>
		</tr>
		<tr>
			<td class="darkrow">&nbsp;</td>
			<td class="darkrow"><strong>Host</strong>: <?php echo DB_HOST?></td>
		</tr>
		<tr>
			<td class="darkrow">&nbsp;</td>
			<td class="lightrow"><strong>Username</strong>: <?php echo DB_USER?></td>
		</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="darkrow">Connecting to DB server...
				<?php
if(@mysql_connect(DB_HOST,DB_USER,DB_PASS))
echo "OK";
else
echo "<span class=\"error\">ERROR:</span> ".mysql_error();
?></td>
		</tr>
		<tr>
			<td class="darkrow">&nbsp;</td>
			<td class="lightrow"><strong>DB Name</strong> (schema): <?php echo DB_SCHEMA?></td>
		</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="darkrow">Selecting database...
				<?php
if(@mysql_select_db(DB_SCHEMA))
echo "OK";
else
echo "<span class=\"error\">ERROR:</span> ".mysql_error();
?>
</td>
		</tr>
		<tr>
			<td class="darkrow"><span class="lightrow"><img src="triangle.gif" width="10" height="11" /></span></td>
			<td class="lightrow">Checking for required tables...<br />
<?php
	// check tables
	$tablesres = @mysql_query("SHOW TABLES") or die(mysql_error());
	$required_tables = array(DB_DEVICE_TABLE,DB_PATCH_TABLE,DB_HYBRID_TABLE,DB_CACHE_TABLE);
	$tables = array();
	while($table = @mysql_fetch_row($tablesres))$tables[]=$table[0];
	//var_export($tables);
	foreach($required_tables as $req_table){
		echo "--- table '$req_table'...";
		if(!@in_array($req_table,$tables)){
			echo "missing in database (".DB_SCHEMA."), creating...";
			echo @emptyWurflDevTable($req_table)? "OK": "<span class=\"error\">Error</span> ".mysql_error();
			echo "<br/>\n";
		}else{
			echo "OK";
			echo "<br/>\n";
		}
	}
?>
</td>
		</tr>
		<tr>
			<td class="darkrow">&nbsp;</td>
			<td class="darkrow"><div align="left" style="padding-left:15px;"><br />
				 If everything looks ok, <strong>delete <?=CLASS_DIRNAME?>/admin/install.php</strong>, then update your database from one of the following sources:<br />
				 <a href="tera_wurfl_updatedb.php?source=local&amp;type=main">Your local WURFL file</a> (<?=WURFL_FILE?>)<br />
				 <a href="tera_wurfl_updatedb.php?source=remote&amp;type=main">The current released WURFL</a> (<?=WURFL_DL_URL?>)<br />
				 <a href="tera_wurfl_updatedb.php?source=remote_cvs&amp;type=main">The current CVS WURFL</a> (<?=WURFL_CVS_URL?>)<br />
				 &nbsp;<br />
			</div></td>
		</tr>
	</table>
	</td>
</tr></table>
</body>
</html>
