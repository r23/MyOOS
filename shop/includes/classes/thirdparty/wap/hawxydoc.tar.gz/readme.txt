Copyright (C) Norbert Huffschmid (2002).  All Rights Reserved

These files and translations of it may be copied and furnished to
others, and derivative works that comment on or otherwise explain it
or assist in its usage may be prepared, copied, published
and distributed, in whole or in part, without restriction of any
kind, provided that the above copyright notice and this readme file are
included on all such copies and derivative works.  However, these
files may not be modified in any way, except as required to
translate it into languages other than English.

These files and the information contained herein is provided on an
"AS IS" basis and THE AUTHOR DISCLAIMS ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE
INFORMATION HEREIN WILL NOT INFRINGE ANY RIGHTS OR ANY IMPLIED
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.



Entry point:
============

Direct your browser to en/index.htm 



Important note for translators:
===============================

This reference has been created using XML and XSLT techniques. You are
welcome to translate this reference into other languages of your choice.
If you do so, you SHOULD translate not the .HTM files, but the .XML files
contained in the en/src directory. All tag_*.hml files are automatically
created from their corresponding tag_*.xml source file. All other files
have to be translated directly, if required.

The conversion to HTM format is done by the hawxydoc.xsl transformation
file. If you are not familiar with this XSLT processing stuff, you are
welcome to contact me for assistance.

Keep on laughing,
Norbert Huffschmid
